#pragma once

#include <torch/csrc/python_headers.h>

namespace torch {
namespace multiprocessing {

PyMethodDef* python_functions();

} // namespace multiprocessing
} // namespace torch
