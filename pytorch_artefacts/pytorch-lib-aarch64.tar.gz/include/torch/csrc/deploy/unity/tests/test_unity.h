#pragma once

// NOLINTNEXTLINE
static char TEST_PYTHON_APP_DIR_TEMP[] =
    "/tmp/torch_deploy_unity_unittest_XXXXXX";
