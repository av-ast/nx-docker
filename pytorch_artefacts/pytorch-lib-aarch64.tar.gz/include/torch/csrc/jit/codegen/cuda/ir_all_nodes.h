#pragma once

#include <torch/csrc/jit/codegen/cuda/ir_base_nodes.h>
#include <torch/csrc/jit/codegen/cuda/ir_interface_nodes.h>
#include <torch/csrc/jit/codegen/cuda/ir_internal_nodes.h>

// TODO: remove this once the Kernel IR split is complete
#include <torch/csrc/jit/codegen/cuda/kernel_ir.h>
