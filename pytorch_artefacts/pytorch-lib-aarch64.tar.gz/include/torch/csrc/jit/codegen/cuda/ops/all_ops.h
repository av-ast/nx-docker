#pragma once
#include <torch/csrc/jit/codegen/cuda/arith.h>
#include <torch/csrc/jit/codegen/cuda/ops/composite.h>
#include <torch/csrc/jit/codegen/cuda/ops/normalization.h>
