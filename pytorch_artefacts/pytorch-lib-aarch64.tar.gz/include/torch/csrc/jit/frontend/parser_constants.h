#pragma once

namespace torch {
namespace jit {
static const char* valid_single_char_tokens = "+-*/%@()[]:,={}><.?!&^|~";
} // namespace jit
} // namespace torch
