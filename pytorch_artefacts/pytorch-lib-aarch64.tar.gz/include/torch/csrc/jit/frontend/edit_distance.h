#pragma once

#include <torch/csrc/Export.h>
#include <cstddef>

namespace torch {
namespace jit {

TORCH_API size_t ComputeEditDistance(
    const char* word1,
    const char* word2,
    size_t maxEditDistance);

} // namespace jit
} // namespace torch
